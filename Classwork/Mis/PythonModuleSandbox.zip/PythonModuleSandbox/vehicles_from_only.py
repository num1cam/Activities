from cars_and_trucks import get_all_automobiles
from nautical import civilian

print(get_all_automobiles())

print(civilian.get_all_boats())