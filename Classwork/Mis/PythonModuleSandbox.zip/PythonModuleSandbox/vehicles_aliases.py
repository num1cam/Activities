import cars_and_trucks as cat
from nautical import civilian as civ

print(cat.get_all_automobiles())

print(civ.get_all_boats())