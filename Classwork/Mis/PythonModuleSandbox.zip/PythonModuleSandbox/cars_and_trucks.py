def get_all_automobiles():
    return ["sedan", "pickup", "hatchback"]
