import cars_and_trucks
import nautical.civilian

print(cars_and_trucks.get_all_automobiles())

print(nautical.civilian.get_all_boats())