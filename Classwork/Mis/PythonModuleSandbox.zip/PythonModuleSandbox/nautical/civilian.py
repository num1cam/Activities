def get_all_boats():
    return ["cruiseliner", "yacht", "jetski"]
