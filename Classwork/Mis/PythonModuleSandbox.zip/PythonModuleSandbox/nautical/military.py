def get_all_boats():
    return ["patrol","destroyer","carrier","cruiser"]
